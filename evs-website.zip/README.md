# EVS Website

IMPORTANT!
Please follow the guide at the link below to contribute to the website code. Do not create branches directly and/or push to master. 

https://akrabat.com/the-beginners-guide-to-contributing-to-a-github-project/
